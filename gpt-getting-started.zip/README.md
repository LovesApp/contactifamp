# Display a test ad

This example displays a test ad using the Google Publisher Tag library. See
[Get Started with Google Publisher Tags][get_started] to learn more about how
this sample works.

[get_started]: https://developers.google.com/publisher-tag/guides/get-started
